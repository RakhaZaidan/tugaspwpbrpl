<?php
defined("BASEPATH") OR exit ('Not direct script accsess allowed');
Class Belajar extends  CI_Controller {
	function _construct() {
	parent ::_construct();
	}
public function index(){
	echo"ini method index untuk controller belajar";
 }
public function halo (){
	$this->load->view('view_belajar');
 }

}