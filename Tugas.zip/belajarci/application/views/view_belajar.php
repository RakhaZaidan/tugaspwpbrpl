<! DOCTYPE html>
<html>
<head>
<title> Cara membuat view pada codeinteger By Rakha Zaidan</title>
</head>
<body>
<h1>  Ini adalah view_belajar.php</h1>
<h2> Halo ini adalah Daftar Riwayat Hidup Saya</h2>
<h3> Nama: Rakha Zaidan Nabil</h3>
<h3> Alamat:Jl.Rukun Mulya Kel. Babakan Penghulu Kec. Cinambo</h3>
<h3> Kewarganegaraan: Indonesia</h3>
<h3> Agama: Islam</h3>
<h3> Tempat tanggal lahir: Bandung, 31-januari-2003</h3>
<h3> Jenis kelamin : Laki-Laki</h3>
<h3> Nomor Telpon: 081915557068 </h3>
<h3> Email: rakhanabil61@ggmail.com</h3>

<p> Pengalaman</p>
<p> Sewaktu SD saya pernah mengikuti Lomba 17 Agustus untuk merayakan Hari Kemerdekaan Indonesia Di sekolah BAnyak perlombaan yamg dilombakan contoh balap karung,makan kerupuk memasukan paku ke dalam botol dan masih banyak lagi ada juga perlombaan yang berhubungan dengan kegiatan olahraga contohnya basket,seoak bolla dan bulu tangkis saya mengikuti perlombaan sepak bolla dengan teman sekelas saya dan saya jugga ikut dalam lomba bulu tangkis dalam lomba sepak bola tim saya juara 4 sedangkan untuk bulu tangis saya mendapatkan juara ke 5</p>
</body>
</html>
